	//Name______________________________ Date_____________
    public class Salesperson 
   {
   	//data fields
      private String myName;
      private int myCars, myTrucks;
   
   	//constructors
   
         	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
   
   
   	//accessors and modifiers
   
         	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
   
   
   	//other methods: toString
   
         	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
   }