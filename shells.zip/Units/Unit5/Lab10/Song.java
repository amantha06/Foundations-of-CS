//Name______________________________ Date_____________

    public class Song implements Comparable<Song>
   {
   	//data fields
      private String myTitle;
      private int myMinutes, mySeconds;
   
   	//constructors
       public Song(String toBeParsed)
      {
           	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
      }
     
   	//accessors and modifiers
      
      
   	
       
      //other methods:  compareTo(), equals(), toString()
      
   	
   	
   }