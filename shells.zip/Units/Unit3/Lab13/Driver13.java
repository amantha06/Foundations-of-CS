//name:    date:

import javax.swing.JOptionPane;
public class Driver13
{
   public static int first;
   public static int second;
   public static void main(String[] args)
   {
      while(true)
      {
         /* prompt the user for first */
         
         /* if -1, exit  */
                  
         /* prompt the user for second */
                 
         necklace(first, second);
      }
   }
   public static void necklace(int a, int b)
   {
      /* enter code here  */
   }
}